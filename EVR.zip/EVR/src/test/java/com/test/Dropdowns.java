package com.test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.chrome.ChromeDriver;

public class Dropdowns {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.edgedriver().setup();
		WebDriver driver=new EdgeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://www.globalsqa.com/demo-site/select-dropdown-menu/");
		driver.get("https://chercher.tech/practice/practice-dropdowns-selenium-webdriver");
		driver.navigate().back();
		
		//Select drop down using Slect methods 
		//WebElement dropdown=driver.findElement(By.xpath("//div[@class='single_tab_div resp-tab-content resp-tab-content-active']//p//select"));
		Select dropdowncountry=new Select(driver.findElement(By.xpath("//div[@class='single_tab_div resp-tab-content resp-tab-content-active']//p//select")));
		//dropdowncountry.selectByVisibleText("India");
		//dropdowncountry.selectByValue("AGO");
		dropdowncountry.selectByIndex(11);
		
		driver.navigate().forward();
		//handling mutiple drop downs
		Select multipledd=new Select(driver.findElement(By.xpath("//*[@id=\"first\"]")));
		multipledd.selectByIndex(3);
		Select multipledd2=new Select(driver.findElement(By.xpath("//*[@id=\"animals\"]")));
		multipledd2.selectByValue("big baby cat");
		
		
		
		
		
		
		
	}

}
