package com.test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
public class FindElementvsFindElements {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriverManager.edgedriver().setup();
		WebDriver driver=new EdgeDriver();
		driver.get("https://admin-demo.nopcommerce.com/login");
		driver.get("https://demo.nopcommerce.com/register?returnUrl=%2F");
		driver.findElement(By.xpath("//input[@id='small-searchterms']")).sendKeys("XYZ");
		//WebElement ele=driver.findElement(By.xpath("//div[@class='footer-upper']"));
		//System.out.println(ele.getSize());
		WebElement newsletter=driver.findElement(By.xpath("//input[@id='Newsletter']"));
		System.out.println(newsletter.isSelected());
		driver.navigate().back();
		
		WebElement Username=driver.findElement(By.id("Email"));
		Username.clear();
		Username.sendKeys("adminanitha123gmail.com");
		//getAttribute()-it returns the value of an any attribute.
		System.out.println("Results of getAttribute() method:"+Username.getAttribute("value"));
		
		//getText()-It returns the value of text.
		WebElement button=driver.findElement(By.xpath("/html/body/div[6]/div/div/div/div/div[2]/div[1]/div/form/div[3]/button"));
		System.out.println("Results of getText():"+button.getText());
		System.out.println(driver.getTitle());
		Thread.sleep(3000);
		
		
		
	}

}
