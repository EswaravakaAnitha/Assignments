package com.test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;

import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.edge.EdgeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class OpenBrowser {	

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		//WebDriverManager.edgedriver().setup();
		//WebDriver driver = new EdgeDriver();
		//driver.get("https://www.flipkart.com/");
		//driver.close();
		//ChromeOptions ops=new ChromeOptions();
		//ops.addArguments("--remote-allow-origins=*");
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\a888414\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		//driver = new ChromeDriver(ops);
		//System.out.println("Ani");
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		System.out.println("Anitha");
		
		//Open 
		driver.navigate().to("https://www.snapdeal.com/");
		driver.get("https://demo.nopcommerce.com/register?returnUrl=%2F");
		//Capture Title
		System.out.println("Title of the webpage:"+driver.getTitle());
		//Capture URL
		System.out.println("Title of the webpage"+driver.getCurrentUrl());
		//Capture pagesource
		System.out.println(driver.getPageSource());
	//	driver.findElement(By.xpath("//a[text()='Computers']")).click();
		
		WebElement Searchbox=driver.findElement(By.xpath("//input[@id='small-searchterms']"));
		//is Displayed
		//is Enabled
		System.out.println("Display status:"+Searchbox.isDisplayed());
		System.out.println("Enabled status:"+Searchbox.isEnabled());
		//Searchbox.isEnabled();
		//WebElement check=driver.findElement(By.xpath("//body/div[@class='master-wrapper-page']/div[@class='header-menu']/ul[@class='top-menu notmobile']/li[1]"));
		//System.out.println("dskjlkk:"+check.isEnabled());
		//if(check.isEnabled()) { 
	     //   System.out.println("Enabled"+check.isEnabled()); 
	    // }
		//else
	//	{
		//	System.out.println("not enabled"+check.isEnabled());
		//}
		//check.findElement(By.xpath("//body/div[@class='master-wrapper-page']/div[@class='header-menu']/ul[@class='top-menu notmobile']/li[1]")).click();
		//driver.findElement(By.xpath("//a[@text()='Computers']")).click();
		//is Selected
		WebElement male=driver.findElement(By.xpath("//input[@id='gender-male']"));
		WebElement female=driver.findElement(By.xpath("//input[@id='gender-female']"));
		System.out.println(male.isSelected());
		System.out.println(female.isSelected());
		
		male.click();
		Thread.sleep(3000);
		System.out.println(male.isSelected());
		System.out.println(female.isSelected());
		
		female.click();
		Thread.sleep(3000);
		System.out.println(male.isSelected());
		System.out.println(female.isSelected());
		
		//navigate methods
		driver.navigate().back();
		driver.navigate().forward();
		driver.navigate().refresh();
		Thread.sleep(3000);
		
		
		//To close the browser.
		driver.close();
	}

}
