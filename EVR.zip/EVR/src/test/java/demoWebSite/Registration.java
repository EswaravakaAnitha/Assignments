package demoWebSite;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
public class Registration {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
try {	
	try {
		
		driver.get("https://www.tutorialsninja.com/demo/");
		//System.out.println("Your Store Website opened successfully");
		Thread.sleep(2000);
		driver.manage().window().maximize();
		String actURL=driver.getCurrentUrl();
		String expURL="https://www.tutorialsninja.com/demo/";
		if(actURL.equals(expURL))
		{
			System.out.println("URL Matched");
			System.out.println("website opened");
			String actualTitle = driver.getTitle();
			String expectedTitle="Your Store";
			if(actualTitle.equals(expectedTitle))
			{
				System.out.println("Title matched to expected title-Title verified successfully");
			}
			else
			{
				System.out.println("Title Does not matched");
			}
		}
		else
		{
			System.out.println("URL does not matched");
			System.out.println("Failed to launch WebPage");
		}

	driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a")).click();
	driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[1]/a")).click();
	System.out.println("Click on Registration button");
	Thread.sleep(2000);
	driver.findElement(By.name("firstname")).sendKeys("Anitha");
	Thread.sleep(1000);
	driver.findElement(By.id("input-lastname")).sendKeys("Eswaravaka");
	Thread.sleep(1000);
	driver.findElement(By.xpath("//input[@id='input-email']")).sendKeys("2saszwsahssfadjhi@gmail.com");
	Thread.sleep(1000);
	driver.findElement(By.name("telephone")).sendKeys("8465831571");
	Thread.sleep(1000);
	driver.findElement(By.name("password")).sendKeys("SHIVA@123parvati");
	Thread.sleep(1000);
	driver.findElement(By.id("input-confirm")).sendKeys("SHIVA@123parvati");
	Thread.sleep(1000);
	WebElement newsletterbutton=driver.findElement(By.xpath("(//input[@name='newsletter'])[1]"));
	newsletterbutton.click();
	Thread.sleep(1000);
	WebElement checkbox=driver.findElement(By.name("agree"));
	checkbox.click();
	driver.findElement(By.xpath("//input[@value='Continue']")).click();
	}
	catch(Exception fields)
	{
		fields.printStackTrace();
	}
	System.out.println("All details entered successfully");
	Thread.sleep(2000);
	
	WebElement succmsg = driver.findElement(By.xpath("//*[@id=\"content\"]/h1"));
	if(succmsg.isEnabled()&&succmsg.getText().contains("Your Account Has Been Created!"))
	{
		System.out.println("your account has been created successfully");
	}
	else
	{
		throw new RuntimeException("Registration failed - Check all manditory fields are entered or not");
	}
	WebElement continuebutt=driver.findElement(By.xpath("//*[@id=\"content\"]/div/div/a"));
	continuebutt.click();
	System.out.println("Continue button is Enabled");
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//*[@id=\"search\"]/input")).sendKeys("Macbook");
	Thread.sleep(1000);
	driver.findElement(By.xpath("//*[@id=\"search\"]/span/button")).click();
	Thread.sleep(1000);
	driver.findElement(By.xpath("//img[@title='MacBook']")).click();
	Thread.sleep(1000);
	System.out.println("Search Mac book sucessfully");
	driver.findElement(By.id("button-cart")).click();
	Thread.sleep(1000);
	WebElement addtocartmsg=driver.findElement(By.xpath("//div[@class='alert alert-success alert-dismissible']"));
	if(addtocartmsg.getText().contains("Success: You have added MacBook to your shopping cart!"))
	{
		System.out.println("Product added to cart successfully");
	}
	else
	{
		System.out.println("Failed to add the Product i Cart");
	}
	driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[4]/a")).click();
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//a[@class='btn btn-primary']")).click();
	System.out.println("Clicked on check out button");
	Thread.sleep(3000);
	WebElement fn=driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div[2]/div/form/div[1]/div[1]/div/input"));
	fn.sendKeys("Anitha");
	Thread.sleep(1000);
	driver.findElement(By.id("input-payment-lastname")).sendKeys("Eswaravaka");
	Thread.sleep(1000);
	driver.findElement(By.id("input-payment-address-1")).sendKeys("Tirupati,AP");
	Thread.sleep(1000);
	driver.findElement(By.id("input-payment-city")).sendKeys("Tirupati");
	Thread.sleep(1000);
	driver.findElement(By.id("input-payment-postcode")).sendKeys("524404");
	Thread.sleep(1000);
	WebElement country=driver.findElement(By.xpath("//*[@id=\"input-payment-country\"]"));
	country.findElement(By.xpath("//option[@value='99']")).click();
	Thread.sleep(1000);
	WebElement state=driver.findElement(By.xpath("//*[@id=\"input-payment-zone\"]"));
	state.findElement(By.xpath("//option[@value='1476']")).click();
	Thread.sleep(1000);
	System.out.println("All  mandatory fields are filled  successfully");
	WebElement conbut=driver.findElement(By.id("button-payment-address"));
	conbut.click();	
	Thread.sleep(3000);
	WebElement msg=driver.findElement(By.xpath("//div[@class='alert alert-warning alert-dismissible']"));
	
	if(msg.getText().contains("Go to Payment Options-Your details are saved successfully"))
	{
		System.out.println("Payment options are available");
	}
	else
	{
		throw new RuntimeException("Warning: No Payment options are available. Please contact us for assistance!");
	}
	Thread.sleep(3000);
	driver.findElement(By.xpath("//i[@class='fa fa-phone']")).click();
	Thread.sleep(1000);
	driver.findElement(By.id("input-enquiry")).sendKeys("I am not able to see the Payment options");
	Thread.sleep(1000);
	driver.findElement(By.xpath("//input[@value='Submit']")).click();
	Thread.sleep(1000);
	driver.findElement(By.className("btn btn-primary")).click();
	Thread.sleep(3000);
	}

catch(Exception name) {
	name.printStackTrace();	
}

finally {
	driver.quit();
}
		
	}
 
}
