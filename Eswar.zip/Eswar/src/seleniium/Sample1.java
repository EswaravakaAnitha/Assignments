package seleniium;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Sample1 {
			public static void main(String[] args) {
				WebDriver driver;
			System.setProperty("webdriver.chrome.driver","C:\\Users\\a888414\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
			driver=new ChromeDriver();
			driver.manage().window().maximize();
			System.out.println("browser opened successfully");
			driver.get("https://www.flipkart.com/");
			System.out.println("website opened successfully");
			//Thread.sleep(5000);
			WebElement tshirt=driver.findElement(By.name("q"));
			tshirt.sendKeys("Tshirts");
			System.out.println("Searching Tshirts in the Website");
			tshirt.sendKeys(Keys.ENTER);
			driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div/span[4]")).click();
			driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div/a[2]")).click();
			driver.close();

	}

}
