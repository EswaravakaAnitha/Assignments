package seleniium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import dev.failsafe.internal.util.Assert;

public class Sample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver.", "C:\\Users\\a888414\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		System.out.println("Browser opened");
		driver.manage().window().maximize();
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
		System.out.println("Website opened");
		driver.getTitle();
		driver.findElement(By.name("firstname")).sendKeys("Anitha");
		System.out.println("FirstName entered");
		driver.findElement(By.name("lastname")).sendKeys("Eswaravaka");
		System.out.println("LastName entered");
		driver.findElement(By.id("sex-1")).click();
		System.out.println("Gender button clicked");
		driver.findElement(By.id("exp-0")).click();
		System.out.println("YOE clicked");
		driver.findElement(By.id("datepicker")).sendKeys("30-10-2023");
		System.out.println("Date entered");
		driver.findElement(By.xpath("//input[@id=\"profession-0\"]")).click();
		System.out.println("Profession selected 1");
		driver.findElement(By.xpath("//input[@id=\"profession-1\"]")).click();
		System.out.println("Profession selected 2");
		driver.findElement(By.id("tool-2")).click();
		System.out.println("Automaion tols selected");;
		//driver.findElement(By.id("continents")).click();
		WebElement Continents=driver.findElement(By.id("continents"));	
		Continents.findElement(By.xpath("//*[@id=\"continents\"]/option[4]")).click();
        System.out.println("Cntinent selected");
		WebElement Selcomm=driver.findElement(By.id("selenium_commands"));
		Selcomm.findElement(By.xpath("//*[@id=\"selenium_commands\"]/option[3]")).click();
		System.out.println("Selenium commands selected");
		WebElement FileUpload=driver.findElement(By.className("input-file"));
		FileUpload.sendKeys("C:\\Users\\a888414\\OneDrive - Atos\\Desktop\\Anitha\\Anitha Photo.png");
		System.out.println("File Uploaded successfully");
		WebElement button=driver.findElement(By.xpath("//*[@id=\\\"submit\\"));
		//button.findElement(By.xpath("//*[@id=\"submit\"]")).click();
		System.out.println("dhbsddsa:"+button.isEnabled());
		//System.out.println("Data submitted successfully");
		
		 //Assert.assertFalse(isElementEnabled);
		//driver.close();
	}
}
