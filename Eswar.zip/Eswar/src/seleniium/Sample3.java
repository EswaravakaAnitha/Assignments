package seleniium;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
public class Sample3 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://tutorialsninja.com/demo/index.php?route=checkout/checkout");
		//System.out.println("Your Store Website opened successfully");
		Thread.sleep(2000);
		driver.manage().window().maximize();
		WebElement fn=driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div[2]/div/form/div[1]/div[1]/div/input"));
		fn.sendKeys("Anitha");
		driver.findElement(By.id("input-payment-lastname")).sendKeys("Eswaravaka");
		driver.findElement(By.id("input-payment-address-1")).sendKeys("Tirupati,AP");
		driver.findElement(By.id("input-payment-city")).sendKeys("Tirupati");
		driver.findElement(By.id("input-payment-postcode")).sendKeys("524404");
		WebElement country=driver.findElement(By.xpath("//*[@id=\"input-payment-country\"]"));
		country.findElement(By.xpath("//option[@value='99']")).click();
		WebElement state=driver.findElement(By.xpath("//*[@id=\"input-payment-zone\"]"));
		state.findElement(By.xpath("//option[@value='1476']")).click();
		WebElement conbut=driver.findElement(By.id("button-payment-address"));
		conbut.click();
		
		
		
	}
}